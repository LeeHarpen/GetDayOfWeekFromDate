//Copyright by DevLhp at 2025.2. All Rights Reserved.

#pragma once

#include "Modules/ModuleManager.h"

class FGetDayOfWeekFromDateModule : public IModuleInterface
{
public:

	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;
};
