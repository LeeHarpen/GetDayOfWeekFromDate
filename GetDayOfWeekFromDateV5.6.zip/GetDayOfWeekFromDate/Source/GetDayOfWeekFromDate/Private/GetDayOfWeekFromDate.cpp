//Copyright by DevLhp at 2025.2. All Rights Reserved.

#include "GetDayOfWeekFromDate.h"

#define LOCTEXT_NAMESPACE "FGetDayOfWeekFromDateModule"

void FGetDayOfWeekFromDateModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
	
}

void FGetDayOfWeekFromDateModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
	
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FGetDayOfWeekFromDateModule, GetDayOfWeekFromDate)