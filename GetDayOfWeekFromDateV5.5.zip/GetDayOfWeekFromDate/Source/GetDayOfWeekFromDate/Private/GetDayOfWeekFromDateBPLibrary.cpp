// DevLhp.

#include "GetDayOfWeekFromDateBPLibrary.h"
#include "GetDayOfWeekFromDate.h"

UGetDayOfWeekFromDateBPLibrary::UGetDayOfWeekFromDateBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

//void UGetDayOfWeekFromDateBPLibrary::DateToWeekDay(int Year, int Month, int Day, TArray<FString> DayString, int& WeekDay, FString& WeekDayString, bool& ValidDate)

void UGetDayOfWeekFromDateBPLibrary::DateToWeekDay(int Year, int Month, int Day, int& WeekDay, bool& ValidDate)
{
	int CalcYear;
	int CalcMonth;

//Check Date is valid
	ValidDate = CheckDateValid(Year, Month, Day);
//Check Date is valid

	if (ValidDate)
	{
		if (Month < 3)
		{
			CalcYear = Year - 1;
			CalcMonth = Month + 12;
		}
		else
		{
			CalcYear = Year;
			CalcMonth = Month;
		}

		int c = CalcYear / 100;
		int y = CalcYear % 100;
		int D = (c / 4) - (2 * c) + y + (y / 4) + (13 * (CalcMonth + 1) / 5) + Day - 1;
		int W = D % 7;

		//if (W == 0)
		//{
		//	WeekDay = 0; //Sunday
		//}
		//else
		//{
			WeekDay = W; //0=sunday 1=monday
		//}

		//if (DayString.IsValidIndex(W))
		//{
		//	WeekDayString = DayString[W];
		//}
	}
	//else
	//{
	//	//InValid Date
	//	WeekDayString = "Date is invalid";
	//}
}

//Check Date is valid
bool UGetDayOfWeekFromDateBPLibrary::CheckDateValid(int Year, int Month, int Day)
{
	TArray<int32> BMonthArray;
	TArray<int32> SMonthArray;

	BMonthArray = { 1,3,5,7,8,10,12 };	//Month with 31 days
	SMonthArray = { 4,6,9,11 }; //Month with 30 days

	if (Day < 1)
	{
		return false;
	}

	if (Month < 1 or Month > 12)
	{
		return false;
	}

	if ((BMonthArray.Contains(Month) and Day > 31) or (SMonthArray.Contains(Month) and Day > 30))
	{
		return false;
	}

	if (Month == 2)
	{
		if ((Year % 4 == 0 && Year % 100 != 0) || (Year % 400 == 0))
		{
			if (Day > 29)
				return false;
		}
		else
		{
			if (Day > 28)
				return false;
		}
	}
	return true;
}
